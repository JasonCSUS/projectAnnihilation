#include "MovementSystem.h"
#include "AnimationManager.h"
#include "EntityManager.h"
#include "NavMesh.h"
#include "Rigidbodies.h"

#include <cmath>

namespace {
constexpr float kMinMoveEpsilon = 0.001f;

enum class MoveDir { Right, Left, Down, Up };

MoveDir DirFromDelta(float dx, float dy) {
    if (std::abs(dx) >= std::abs(dy)) {
        return dx >= 0.0f ? MoveDir::Right : MoveDir::Left;
    }
    return dy >= 0.0f ? MoveDir::Down : MoveDir::Up;
}

MoveDir DirFromAngle(float angleDegrees) {
    const float rad = angleDegrees * static_cast<float>(3.14159265358979323846 / 180.0);
    return DirFromDelta(std::cos(rad), std::sin(rad));
}

void PlayMoveAnim(AnimationManager& animationManager, int entityId, MoveDir dir) {
    bool flipX = false;
    const char* animId = nullptr;
    switch (dir) {
        case MoveDir::Right: animId = "move_right"; flipX = false; break;
        case MoveDir::Left:  animId = "move_right"; flipX = true;  break;
        case MoveDir::Down:  animId = "move_down";  flipX = false; break;
        case MoveDir::Up:    animId = "move_up";    flipX = false; break;
    }
    animationManager.PlayAnimation(entityId, animId, 0.15f, true, false, flipX);
}

void PlayIdleAnim(AnimationManager& animationManager, int entityId, MoveDir dir) {
    bool flipX = false;
    const char* animId = nullptr;
    switch (dir) {
        case MoveDir::Right: animId = "idle_right"; flipX = false; break;
        case MoveDir::Left:  animId = "idle_right"; flipX = true;  break;
        case MoveDir::Down:  animId = "idle_down";  flipX = false; break;
        case MoveDir::Up:    animId = "idle_up";    flipX = false; break;
    }
    animationManager.PlayAnimation(entityId, animId, 0.25f, true, false, flipX);
}
} // namespace

void MovementSystem::Update(EntityManager& entityManager, AnimationManager& animationManager, float deltaTime) {
    RigidbodySystem::ClearLastReports();

    for (auto& entity : entityManager.entities) {
        if (entity.isDead) continue;

        if (entity.pathIndex >= entity.path.size()) {
            PlayIdleAnim(animationManager, entity.id, DirFromAngle(entity.movementAngleDegrees));
            continue;
        }

        const Vec2 nextPoint = entity.path[entity.pathIndex];
        const float targetX = static_cast<float>(nextPoint.x);
        const float targetY = static_cast<float>(nextPoint.y);

        float dx = targetX - entity.position.x;
        float dy = targetY - entity.position.y;
        const float distSq = dx * dx + dy * dy;
        const float speed = entity.speed * deltaTime;

        const MoveDir dir = DirFromDelta(dx, dy);
        entity.movementAngleDegrees = static_cast<float>(
            std::atan2(static_cast<double>(dy), static_cast<double>(dx)) * 180.0 / 3.14159265358979323846);

        PlayMoveAnim(animationManager, entity.id, dir);

        // Normalize and cap movement at remaining distance so we don't overshoot
        float nx = dx, ny = dy;
        const float dist = std::sqrt(distSq);
        if (dist > kMinMoveEpsilon) { nx /= dist; ny /= dist; }

        const float step = std::min(speed, dist);
        float moveX = nx * step;
        float moveY = ny * step;

        // Try direct move
        RigidbodySystem::MoveQuery q;
        q.entityId = entity.id;
        q.fromX = entity.position.x;
        q.fromY = entity.position.y;
        q.toX = entity.position.x + moveX;
        q.toY = entity.position.y + moveY;
        auto result = RigidbodySystem::TestMove(q);

        if (!result.blocked) {
            entity.position.x = result.acceptedX;
            entity.position.y = result.acceptedY;
            RigidbodySystem::StoreLastReport(entity.id, result.report);
        } else {
            // Project desired velocity onto the plane perpendicular to each collision normal
            float slideX = moveX, slideY = moveY;
            for (const auto& hit : result.report.hits) {
                const float dot = slideX * hit.normalX + slideY * hit.normalY;
                if (dot < 0.0f) {
                    slideX -= hit.normalX * dot;
                    slideY -= hit.normalY * dot;
                }
            }

            // Try slide
            RigidbodySystem::MoveQuery sq;
            sq.entityId = entity.id;
            sq.fromX = entity.position.x;
            sq.fromY = entity.position.y;
            sq.toX = entity.position.x + slideX;
            sq.toY = entity.position.y + slideY;
            auto slideResult = RigidbodySystem::TestMove(sq);

            if (!slideResult.blocked && (slideX * slideX + slideY * slideY) > kMinMoveEpsilon) {
                entity.position.x = slideResult.acceptedX;
                entity.position.y = slideResult.acceptedY;
                RigidbodySystem::StoreLastReport(entity.id, slideResult.report);
            } else {
                // Fully blocked — report stored so UnitCollisionSystem can react
                RigidbodySystem::StoreLastReport(entity.id, result.report);
            }
        }

        // Soft wall push
        float pushX = 0.f, pushY = 0.f;
        if (NavMesh::Instance().ResolveSoftCollision(
                {static_cast<int>(std::lround(entity.position.x)),
                 static_cast<int>(std::lround(entity.position.y))},
                static_cast<float>(entity.radius),
                pushX, pushY)) {
            entity.position.x += pushX;
            entity.position.y += pushY;
        }

        // Separation push for overlapping entities
        const RigidbodySystem::CollisionReport* storedReport = RigidbodySystem::GetLastReport(entity.id);
        if (storedReport) {
            for (const auto& hit : storedReport->hits) {
                if (hit.kind != RigidbodySystem::CollisionKind::Entity) continue;
                Entity* other = entityManager.GetEntityById(hit.otherEntityId);
                if (!other || other->isDead) continue;
                const float halfPush = hit.overlap * 0.5f;
                entity.position.x += hit.normalX * halfPush;
                entity.position.y += hit.normalY * halfPush;
                other->position.x -= hit.normalX * halfPush;
                other->position.y -= hit.normalY * halfPush;
            }
        }
    }
}
