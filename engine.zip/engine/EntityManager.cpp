#include "EntityManager.h"

#include <SDL3/SDL.h>
#include <algorithm>
#include <iostream>

Entity& EntityManager::AddEntity(int radius,
                                 const SDL_FRect& position,
                                 float speed) {
    static int nextID = 1;

    Entity entity{};
    entity.id = nextID++;
    entity.radius = radius;
    entity.position = position;
    entity.speed = speed;

    entities.push_back(std::move(entity));
    entityIndex[entities.back().id] = entities.size() - 1;
    return entities.back();
}

void EntityManager::RemoveDeadEntities() {
    for (auto it = entities.begin(); it != entities.end(); ) {
        if (it->isDead) {
            animationManager.RemoveEntityAnim(it->id);
            it = entities.erase(it);
        } else {
            ++it;
        }
    }
    entityIndex.clear();
    for (size_t i = 0; i < entities.size(); ++i) {
        entityIndex[entities[i].id] = i;
    }
}

Entity* EntityManager::GetEntityById(int id) {
    const auto it = entityIndex.find(id);
    if (it == entityIndex.end()) return nullptr;
    return &entities[it->second];
}

const Entity* EntityManager::GetEntityById(int id) const {
    const auto it = entityIndex.find(id);
    if (it == entityIndex.end()) return nullptr;
    return &entities[it->second];
}

void EntityManager::RenderEntities(SDL_Renderer* renderer,
                                   float& cameraX,
                                   float& cameraY,
                                   float& cameraW,
                                   float& cameraH,
                                   float /*deltaTime*/) {
    std::vector<Entity*> renderList;
    renderList.reserve(entities.size());

    for (auto& entity : entities) {
        if (!entity.isDead) {
            renderList.push_back(&entity);
        }
    }

    std::stable_sort(renderList.begin(), renderList.end(),
        [](const Entity* a, const Entity* b) {
            if (a->renderPriority != b->renderPriority) {
                return a->renderPriority < b->renderPriority;
            }
            return a->position.y < b->position.y;
        });

    for (Entity* entity : renderList) {
        int spriteW = 0;
        int spriteH = 0;
        if (!animationManager.GetCurrentFrameDrawSize(entity->id, spriteW, spriteH)) {
            continue;
        }

        const int renderX = static_cast<int>(entity->position.x - cameraX);
        const int renderY = static_cast<int>(entity->position.y - cameraY);

        if (renderX + spriteW < 0 || renderX > cameraW ||
            renderY + spriteH < 0 || renderY > cameraH) {
            continue;
        }

        animationManager.RenderEntity(renderer, entity->id, renderX, renderY);
    }
}